import { ArrowUpRight, Menu, UserRound, X } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";

export default function SiteNav({ dark = true }: { dark?: boolean }) {
  const [open, setOpen] = useState(false);
  const { user, isAuthenticated } = useAuth();
  const surface = dark ? "text-white" : "text-[#06111f]";
  return (
    <header className={`relative z-20 mx-auto flex w-full max-w-[1440px] items-center justify-between px-5 py-6 md:px-10 ${surface}`}>
      <Link href="/" className="group flex items-center gap-3" onClick={() => setOpen(false)}>
        <span className="grid h-8 w-8 place-items-center rounded-full border border-current/30 text-sm font-bold transition-transform group-hover:rotate-12">N</span>
        <span className="font-mono text-sm tracking-[0.3em]">NUMI</span>
      </Link>
      <nav className="hidden items-center gap-8 text-[11px] font-semibold uppercase tracking-[0.18em] text-white/60 md:flex">
        <a href="/#collection" className="transition-colors hover:text-white">Collection</a>
        <a href="/#principles" className="transition-colors hover:text-white">The approach</a>
        <a href="/#handover" className="transition-colors hover:text-white">Handover</a>
      </nav>
      <div className="hidden items-center gap-4 md:flex">
        {isAuthenticated ? (
          <Link href={user?.role === "admin" ? "/admin" : "/account"} className="flex items-center gap-2 text-xs text-white/70 transition-colors hover:text-white">
            <UserRound size={15} /> {user?.role === "admin" ? "Owner space" : "My space"}
          </Link>
        ) : (
          <button type="button" onClick={() => startLogin()} className="flex items-center gap-2 text-xs text-white/70 transition-colors hover:text-white">
            <UserRound size={15} /> Sign in
          </button>
        )}
        <a href="/#collection" className="group flex items-center gap-2 rounded-full border border-white/20 px-4 py-2 text-xs font-semibold transition-all hover:border-white/50 hover:bg-white/10">Explore <ArrowUpRight size={14} className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" /></a>
      </div>
      <button type="button" aria-label="Toggle navigation" className="rounded-full border border-white/15 p-2 md:hidden" onClick={() => setOpen((value) => !value)}>{open ? <X size={18} /> : <Menu size={18} />}</button>
      {open && <div className="absolute left-4 right-4 top-[72px] rounded-2xl border border-white/15 bg-[#0b1b2d]/95 p-5 shadow-2xl backdrop-blur-xl md:hidden">
        <div className="flex flex-col gap-4 text-sm text-white/75">
          <a href="/#collection" onClick={() => setOpen(false)}>Collection</a>
          <a href="/#principles" onClick={() => setOpen(false)}>The approach</a>
          <a href="/#handover" onClick={() => setOpen(false)}>Handover</a>
          {isAuthenticated ? <Link href={user?.role === "admin" ? "/admin" : "/account"} onClick={() => setOpen(false)}>Open {user?.role === "admin" ? "owner space" : "my space"}</Link> : <button type="button" className="text-left" onClick={() => startLogin()}>Sign in</button>}
        </div>
      </div>}
    </header>
  );
}
