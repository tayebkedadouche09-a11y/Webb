import { ArrowLeft, ArrowRight, ArrowUpRight, Check, ExternalLink, LockKeyhole, PackageCheck, Play, ShieldCheck, Sparkles } from "lucide-react";
import { Link } from "wouter";
import { toast } from "sonner";
import { useEffect, useMemo } from "react";
import SiteNav from "@/components/SiteNav";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";

function parseFaq(raw: string | null | undefined) {
  if (!raw) return [];
  return raw.split(/\n\n+/).map((block) => {
    const question = block.match(/^Q:\s*(.+)$/m)?.[1]?.trim();
    const answer = block.match(/^A:\s*([\s\S]+)$/m)?.[1]?.trim();
    return question && answer ? { question, answer } : null;
  }).filter((item): item is { question: string; answer: string } => Boolean(item));
}

export default function ProductDetail({ params }: { params: { slug: string } }) {
  const { isAuthenticated } = useAuth();
  const productQuery = trpc.marketplace.getBySlug.useQuery({ slug: params.slug });
  const analyticsEvent = trpc.analytics.event.useMutation();
  const checkout = trpc.orders.checkout.useMutation({
    onSuccess: (session) => window.location.assign(session.url),
    onError: (error) => toast.error("Checkout is not configured yet", { description: error.message }),
  });
  const createOrder = trpc.orders.create.useMutation({
    onSuccess: (result) => {
      toast.success(`Order #${result.orderId} created`, { description: "Opening secure Stripe Checkout…" });
      checkout.mutate({ orderId: result.orderId });
    },
    onError: (error) => toast.error("We could not create the order", { description: error.message }),
  });

  const product = productQuery.data;
  const faq = useMemo(() => parseFaq(product?.faq), [product?.faq]);

  useEffect(() => {
    if (product?.id) analyticsEvent.mutate({ action: "product.view", productId: product.id });
  }, [product?.id]);

  if (productQuery.isLoading) {
    return <div className="numi-shell min-h-screen bg-[#06111f] p-10 text-white/50">Loading product system…</div>;
  }

  if (!product) {
    return <div className="numi-shell min-h-screen bg-[#06111f] p-10 text-white">Product not found. <Link href="/" className="underline">Return home</Link></div>;
  }

  const handlePurchase = () => {
    if (!isAuthenticated) {
      startLogin();
      return;
    }
    createOrder.mutate({ slug: product.slug });
  };

  const hasLiveDemo = Boolean(product.demoUrl);

  return (
    <div className="numi-shell min-h-screen bg-[#06111f]">
      <div className="numi-content">
        <SiteNav />
        <main className="mx-auto max-w-[1440px] px-5 pb-24 md:px-10">
          <Link href="/" className="mb-12 inline-flex items-center gap-2 text-xs uppercase tracking-[.18em] text-white/45 transition-colors hover:text-white">
            <ArrowLeft size={14} /> Back to collection
          </Link>

          <section className="relative overflow-hidden rounded-[36px] border border-white/10 bg-[#071525]/75 p-6 md:p-12 lg:p-14">
            <div className="absolute -right-32 -top-32 h-80 w-80 rounded-full bg-[#2d7ff9]/15 blur-3xl" />
            <div className="absolute -bottom-40 left-1/3 h-80 w-80 rounded-full bg-[#ef8b65]/10 blur-3xl" />
            <div className="relative grid gap-12 lg:grid-cols-[.7fr_1.3fr] lg:items-center">
              <div className="max-w-2xl">
                <div className="mb-6 flex items-center gap-3 font-mono text-[10px] uppercase tracking-[.26em] text-[#83c2ff]">
                  <span className="h-2 w-2 rounded-full bg-[#83c2ff] shadow-[0_0_14px_#83c2ff]" />
                  {product.category}
                </div>
                <h1 className="text-balance text-6xl font-semibold tracking-[-.08em] text-white md:text-8xl">{product.name}</h1>
                <p className="mt-6 text-xl leading-8 text-white/60">{product.tagline}</p>
                <p className="mt-8 max-w-xl text-sm leading-7 text-white/45">{product.description}</p>
                <div className="mt-8 flex flex-wrap gap-2">
                  {product.techStack.slice(0, 6).map((stack) => (
                    <span key={stack.id} className="rounded-full border border-white/10 bg-white/[.04] px-3 py-1.5 font-mono text-[10px] text-white/55">{stack.name}</span>
                  ))}
                </div>
                <div className="mt-10 flex flex-wrap items-center gap-4">
                  <button type="button" onClick={handlePurchase} disabled={createOrder.isPending || checkout.isPending} className="group flex items-center gap-3 rounded-full bg-white px-6 py-3.5 text-sm font-bold text-[#06111f] transition-transform hover:-translate-y-0.5 active:scale-[.98] disabled:cursor-wait disabled:opacity-60">
                    {createOrder.isPending || checkout.isPending ? "Preparing…" : <>Acquire {product.name} <ArrowUpRight size={16} /></>}
                  </button>
                  {hasLiveDemo ? (
                    <a href={product.demoUrl!} target="_blank" rel="noreferrer" onClick={() => analyticsEvent.mutate({ action: "demo.open", productId: product.id })} className="flex items-center gap-2 rounded-full border border-white/15 px-5 py-3.5 text-sm text-white/75 transition-colors hover:border-white/40 hover:text-white">
                      <Play size={14} fill="currentColor" /> View live demo <ExternalLink size={14} />
                    </a>
                  ) : (
                    <span className="flex items-center gap-2 rounded-full border border-white/10 px-5 py-3.5 text-sm text-white/30">
                      Live demo unavailable
                    </span>
                  )}
                </div>
                <div className="mt-7 font-mono text-xs uppercase tracking-[.16em] text-white/35">
                  {product.currency} {Number(product.price).toLocaleString("en-US")} · Single-project commercial license
                </div>
              </div>

              <div className="relative">
                <div className="absolute -inset-6 rounded-[36px] bg-[#2d7ff9]/10 blur-2xl" />
                <div className="product-card relative overflow-hidden rounded-[28px] border border-white/15 bg-[#081a2d] shadow-[0_35px_100px_rgba(0,0,0,.4)]">
                  <div className="aspect-[16/10] overflow-hidden">
                    <img src={product.heroImage} alt={`${product.name} website preview`} className="h-full w-full object-cover" />
                  </div>
                  <div className="flex items-center justify-between border-t border-white/10 px-5 py-4 font-mono text-[9px] uppercase tracking-[.16em] text-white/35">
                    <span>01 / Digital product</span><span>Ready to own</span>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {product.images?.length ? (
            <section className="mt-20">
              <div className="mb-7 flex items-end justify-between gap-6">
                <div>
                  <div className="font-mono text-[10px] uppercase tracking-[.24em] text-[#83c2ff]">02 / Visual system</div>
                  <h2 className="mt-3 text-4xl font-semibold tracking-[-.06em] text-white md:text-5xl">See the system<br /><span className="text-white/35">before you own it.</span></h2>
                </div>
              </div>
              <div className="grid gap-5 md:grid-cols-2">
                {product.images.map((image) => (
                  <figure key={image.id} className="glass overflow-hidden rounded-[28px]">
                    <img src={image.url} alt={image.alt} loading="lazy" className="aspect-[16/10] w-full object-cover" />
                  </figure>
                ))}
              </div>
            </section>
          ) : null}

          <section className="mt-28 grid gap-12 border-t border-white/10 pt-14 lg:grid-cols-[.85fr_1.15fr]">
            <div>
              <div className="mb-5 font-mono text-[10px] uppercase tracking-[.26em] text-[#ef8b65]">03 / What you get</div>
              <h2 className="text-4xl font-semibold tracking-[-.06em] text-white md:text-6xl">A launch surface<br /><span className="text-white/35">with the thinking intact.</span></h2>
            </div>
            <div className="grid gap-4">
              {product.features.map((feature) => (
                <div key={feature.id} className="glass rounded-2xl p-6">
                  <div className="flex items-start gap-4">
                    <span className="mt-1 grid h-7 w-7 shrink-0 place-items-center rounded-full bg-[#2d7ff9]/15 text-[#83c2ff]"><Check size={15} /></span>
                    <div><h3 className="text-base font-semibold text-white">{feature.title}</h3><p className="mt-2 text-sm leading-6 text-white/50">{feature.description}</p></div>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <section className="mt-28 grid gap-6 md:grid-cols-3">
            <div className="glass rounded-3xl p-7">
              <PackageCheck className="mb-8 text-[#83c2ff]" size={23} />
              <div className="font-mono text-[10px] uppercase tracking-[.18em] text-white/35">Included</div>
              <p className="mt-4 text-sm leading-7 text-white/65">{product.included}</p>
            </div>
            <div className="glass rounded-3xl p-7">
              <ShieldCheck className="mb-8 text-[#83c2ff]" size={23} />
              <div className="font-mono text-[10px] uppercase tracking-[.18em] text-white/35">License</div>
              <p className="mt-4 text-sm leading-7 text-white/65">{product.license}</p>
            </div>
            <div className="glass rounded-3xl p-7">
              <LockKeyhole className="mb-8 text-[#ef8b65]" size={23} />
              <div className="font-mono text-[10px] uppercase tracking-[.18em] text-white/35">Requirements</div>
              <p className="mt-4 text-sm leading-7 text-white/65">{product.requirements}</p>
            </div>
          </section>

          <section className="mt-28 border-t border-white/10 pt-14">
            <div className="font-mono text-[10px] uppercase tracking-[.24em] text-[#83c2ff]">04 / Technology</div>
            <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {product.techStack.map((stack) => (
                <div key={stack.id} className="glass rounded-2xl p-5">
                  <Sparkles className="mb-7 text-[#83c2ff]" size={18} />
                  <div className="text-base font-semibold text-white">{stack.name}</div>
                  <div className="mt-2 text-xs text-white/35">{stack.category || "Core system"}</div>
                </div>
              ))}
            </div>
          </section>

          {faq.length ? (
            <section className="mt-28 border-t border-white/10 pt-14">
              <div className="font-mono text-[10px] uppercase tracking-[.24em] text-[#ef8b65]">05 / FAQ</div>
              <h2 className="mt-3 text-4xl font-semibold tracking-[-.06em] text-white md:text-5xl">Questions before<br /><span className="text-white/35">the handover.</span></h2>
              <div className="mt-8 grid gap-4 md:grid-cols-2">
                {faq.map((item) => (
                  <details key={item.question} className="glass group rounded-2xl p-6">
                    <summary className="cursor-pointer list-none pr-8 text-base font-semibold text-white">{item.question}</summary>
                    <p className="mt-4 text-sm leading-7 text-white/50">{item.answer}</p>
                  </details>
                ))}
              </div>
            </section>
          ) : null}

          {product.media?.length ? (
            <section className="mt-28 border-t border-white/10 pt-14">
              <div className="font-mono text-[10px] uppercase tracking-[.24em] text-[#83c2ff]">06 / Motion</div>
              <div className="mt-8 grid gap-5 md:grid-cols-2">
                {product.media.map((media) => (
                  <a key={media.id} href={media.url} target="_blank" rel="noreferrer" className="glass flex items-center gap-4 rounded-2xl p-5 text-sm text-white/70 hover:text-white">
                    <Play size={18} className="text-[#83c2ff]" /> Open {media.kind} preview <ExternalLink size={14} />
                  </a>
                ))}
              </div>
            </section>
          ) : null}

          <section className="mt-28 border-t border-white/10 pt-14">
            <div className="font-mono text-[10px] uppercase tracking-[.24em] text-[#83c2ff]">07 / Handover</div>
            <div className="mt-8 grid gap-4 md:grid-cols-4">
              {[
                ["01", "Payment", "Verified server-side before access is unlocked."],
                ["02", "Provision", "An independent customer instance is prepared when a provider is configured."],
                ["03", "Deploy", "Website and admin URLs are recorded after a successful health-ready response."],
                ["04", "Own", "Source, documentation, and license become available when delivery is ready."],
              ].map(([step, title, copy]) => (
                <div key={step} className="glass rounded-2xl p-6">
                  <div className="font-mono text-[10px] text-[#ef8b65]">{step} /</div>
                  <h3 className="mt-8 text-lg font-semibold text-white">{title}</h3>
                  <p className="mt-3 text-sm leading-6 text-white/45">{copy}</p>
                </div>
              ))}
            </div>
          </section>

          {product.reviews?.length ? (
            <section className="mt-28 border-t border-white/10 pt-12">
              <div className="font-mono text-[10px] uppercase tracking-[.24em] text-[#83c2ff]">08 / Customer notes</div>
              <div className="mt-8 grid gap-4 md:grid-cols-2">
                {product.reviews.map(({ review, user }) => (
                  <article key={review.id} className="glass rounded-2xl p-6">
                    <div className="text-[#ef8b65]">{"★".repeat(review.rating)}<span className="text-white/20">{"★".repeat(5 - review.rating)}</span></div>
                    <h3 className="mt-4 text-base font-semibold text-white">{review.title || "Verified customer"}</h3>
                    <p className="mt-2 text-sm leading-6 text-white/55">{review.body}</p>
                    <div className="mt-4 text-xs text-white/30">{user.name || "NUMI customer"}</div>
                  </article>
                ))}
              </div>
            </section>
          ) : null}

          <section className="mt-28 overflow-hidden rounded-[32px] border border-[#2d7ff9]/25 bg-[#0b1b2d] p-8 md:p-12">
            <div className="flex flex-col justify-between gap-10 md:flex-row md:items-end">
              <div>
                <div className="mb-5 font-mono text-[10px] uppercase tracking-[.26em] text-[#83c2ff]">09 / Final step</div>
                <h2 className="text-4xl font-semibold tracking-[-.06em] text-white md:text-5xl">When it is yours,<br />it stays yours.</h2>
                <p className="mt-5 max-w-xl text-sm leading-7 text-white/50">NUMI creates a pending order first. Payment provider verification happens server-side; only then does the delivery record unlock.</p>
              </div>
              <button type="button" onClick={handlePurchase} disabled={createOrder.isPending || checkout.isPending} className="flex shrink-0 items-center justify-center gap-2 rounded-full bg-[#83c2ff] px-6 py-3.5 text-sm font-bold text-[#06111f] transition-transform hover:-translate-y-0.5 active:scale-[.98] disabled:opacity-60">
                Acquire {product.name} <ArrowUpRight size={16} />
              </button>
            </div>
          </section>

          <Link href="/" className="mt-10 inline-flex items-center gap-2 text-sm text-white/45 hover:text-white"><ArrowRight size={15} /> Return to showroom</Link>
        </main>
      </div>
    </div>
  );
}
